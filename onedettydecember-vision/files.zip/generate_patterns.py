#!/usr/bin/env python3
"""
OneDettyDecember Pattern Generator
Generates high-quality PNG patterns for brand applications
"""

from PIL import Image, ImageDraw
import os

# Brand Colors
COLORS = {
    'detty_gold': (255, 183, 0),
    'unity_black': (26, 26, 26),
    'lagos_red': (230, 57, 70),
    'accra_emerald': (42, 157, 143),
    'highlife_purple': (114, 9, 183),
    'adire_indigo': (38, 70, 83),
    'danfo_yellow': (255, 214, 10),
    'sunset_orange': (251, 133, 0),
    'ocean_blue': (0, 53, 102),
    'white': (255, 255, 255)
}

def create_unity_kente_pattern(size=2000):
    """Creates a Kente-inspired grid pattern"""
    img = Image.new('RGB', (size, size), COLORS['white'])
    draw = ImageDraw.Draw(img)
    
    # Grid size
    grid_size = size // 20
    
    # Draw horizontal stripes
    for i in range(0, size, grid_size * 2):
        # Gold stripe
        draw.rectangle([0, i, size, i + grid_size // 2], fill=COLORS['detty_gold'])
        # Black stripe
        draw.rectangle([0, i + grid_size, size, i + grid_size + grid_size // 4], fill=COLORS['unity_black'])
    
    # Draw vertical stripes
    for i in range(0, size, grid_size * 2):
        # Gold stripe
        draw.rectangle([i, 0, i + grid_size // 2, size], fill=COLORS['detty_gold'])
        # Black stripe
        draw.rectangle([i + grid_size, 0, i + grid_size + grid_size // 4, size], fill=COLORS['unity_black'])
    
    # Add accent colors at intersections
    for x in range(grid_size, size, grid_size * 4):
        for y in range(grid_size, size, grid_size * 4):
            draw.rectangle([x - 10, y - 10, x + 10, y + 10], fill=COLORS['lagos_red'])
    
    return img

def create_adire_circles_pattern(size=2000):
    """Creates an Adire-inspired circular pattern"""
    img = Image.new('RGB', (size, size), COLORS['adire_indigo'])
    draw = ImageDraw.Draw(img)
    
    # Circle spacing
    spacing = size // 10
    radius_large = spacing // 3
    radius_medium = spacing // 5
    radius_small = spacing // 10
    
    for x in range(spacing // 2, size, spacing):
        for y in range(spacing // 2, size, spacing):
            # Outer circle - Gold
            draw.ellipse([x - radius_large, y - radius_large, 
                         x + radius_large, y + radius_large], 
                        outline=COLORS['detty_gold'], width=8)
            
            # Middle circle - Red
            draw.ellipse([x - radius_medium, y - radius_medium, 
                         x + radius_medium, y + radius_medium], 
                        outline=COLORS['lagos_red'], width=5)
            
            # Inner circle - Emerald
            draw.ellipse([x - radius_small, y - radius_small, 
                         x + radius_small, y + radius_small], 
                        fill=COLORS['accra_emerald'])
    
    return img

def create_celebration_diagonal_pattern(size=2000):
    """Creates a dynamic diagonal celebration pattern"""
    img = Image.new('RGB', (size, size), COLORS['unity_black'])
    draw = ImageDraw.Draw(img)
    
    # Diagonal stripe width
    stripe_width = size // 20
    
    # Draw diagonal stripes
    for i in range(-size, size * 2, stripe_width * 4):
        # Gold diagonal
        points = [(i, 0), (i + stripe_width, 0), (i + size + stripe_width, size), (i + size, size)]
        draw.polygon(points, fill=COLORS['detty_gold'])
        
        # Red diagonal
        points = [(i + stripe_width * 2, 0), (i + stripe_width * 3, 0), 
                 (i + size + stripe_width * 3, size), (i + size + stripe_width * 2, size)]
        draw.polygon(points, fill=COLORS['lagos_red'])
    
    # Add accent circles
    for x in range(stripe_width, size, stripe_width * 4):
        for y in range(stripe_width, size, stripe_width * 4):
            draw.ellipse([x - 15, y - 15, x + 15, y + 15], fill=COLORS['accra_emerald'])
    
    return img

def create_lagos_energy_pattern(size=2000):
    """Creates an energetic pattern inspired by Lagos"""
    img = Image.new('RGB', (size, size), COLORS['danfo_yellow'])
    draw = ImageDraw.Draw(img)
    
    # Wave parameters
    wave_height = size // 10
    wave_count = 20
    
    # Draw energy waves
    for i in range(wave_count):
        y_base = (size // wave_count) * i
        for x in range(0, size, 10):
            y = y_base + wave_height * ((x % 100) / 100)
            if i % 3 == 0:
                draw.ellipse([x - 5, y - 5, x + 5, y + 5], fill=COLORS['lagos_red'])
            elif i % 3 == 1:
                draw.ellipse([x - 5, y - 5, x + 5, y + 5], fill=COLORS['sunset_orange'])
            else:
                draw.ellipse([x - 5, y - 5, x + 5, y + 5], fill=COLORS['unity_black'])
    
    return img

def create_accra_heritage_pattern(size=2000):
    """Creates a heritage pattern inspired by Accra"""
    img = Image.new('RGB', (size, size), COLORS['white'])
    draw = ImageDraw.Draw(img)
    
    # Create Black Star pattern
    star_size = size // 20
    spacing = size // 10
    
    for x in range(spacing // 2, size, spacing):
        for y in range(spacing // 2, size, spacing):
            # Draw star (simplified)
            points = []
            for i in range(10):
                angle = i * 36 - 90
                if i % 2 == 0:
                    r = star_size
                else:
                    r = star_size // 2
                import math
                px = x + r * math.cos(math.radians(angle))
                py = y + r * math.sin(math.radians(angle))
                points.append((px, py))
            
            draw.polygon(points, fill=COLORS['unity_black'])
            
            # Add circle around star
            draw.ellipse([x - star_size - 10, y - star_size - 10,
                         x + star_size + 10, y + star_size + 10],
                        outline=COLORS['detty_gold'], width=3)
    
    # Add connecting lines
    for x in range(0, size, spacing):
        draw.line([(x, 0), (x, size)], fill=COLORS['accra_emerald'], width=2)
        draw.line([(0, x), (size, x)], fill=COLORS['accra_emerald'], width=2)
    
    return img

def create_rhythm_pattern(size=2000):
    """Creates a rhythm visualization pattern"""
    img = Image.new('RGB', (size, size), COLORS['white'])
    draw = ImageDraw.Draw(img)
    
    # Bar width and spacing
    bar_width = size // 50
    spacing = bar_width * 2
    
    # Draw rhythm bars
    for x in range(0, size, spacing):
        import random
        height = random.randint(size // 10, size // 2)
        y_start = size - height
        
        color_choice = [COLORS['detty_gold'], COLORS['lagos_red'], 
                       COLORS['accra_emerald'], COLORS['highlife_purple']]
        color = random.choice(color_choice)
        
        draw.rectangle([x, y_start, x + bar_width, size], fill=color)
        
        # Add echo effect
        for i in range(1, 4):
            echo_height = height // (i + 1)
            echo_y = size - echo_height
            alpha_color = (*color, 255 // (i + 1))
            draw.rectangle([x, echo_y - (i * 10), x + bar_width, echo_y - (i * 10) + 5], 
                          fill=color)
    
    return img

def save_all_patterns(output_dir='patterns'):
    """Generate and save all patterns"""
    os.makedirs(output_dir, exist_ok=True)
    
    patterns = [
        ('unity_kente', create_unity_kente_pattern),
        ('adire_circles', create_adire_circles_pattern),
        ('celebration_diagonal', create_celebration_diagonal_pattern),
        ('lagos_energy', create_lagos_energy_pattern),
        ('accra_heritage', create_accra_heritage_pattern),
        ('rhythm_visualization', create_rhythm_pattern)
    ]
    
    for name, pattern_func in patterns:
        print(f"Generating {name} pattern...")
        
        # Generate in multiple sizes
        for size in [500, 1000, 2000]:
            img = pattern_func(size)
            filename = f"{output_dir}/onedettydecember_{name}_{size}px.png"
            img.save(filename, 'PNG', quality=95, optimize=True)
            print(f"  Saved: {filename}")
    
    print("\n✅ All patterns generated successfully!")
    print(f"📁 Files saved in: {os.path.abspath(output_dir)}/")

if __name__ == "__main__":
    save_all_patterns()
    print("\n🎨 OneDettyDecember Pattern Generation Complete!")
    print("Use these patterns for:")
    print("  • Website backgrounds (10-20% opacity)")
    print("  • Social media templates")
    print("  • Merchandise designs")
    print("  • Event materials")
    print("  • Brand collateral")
