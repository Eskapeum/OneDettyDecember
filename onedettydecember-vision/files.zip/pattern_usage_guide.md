# OneDettyDecember Pattern Usage Guide
## Cultural Patterns for Digital & Print

---

## 📦 Your Pattern Package Includes:

### 18 High-Quality PNG Patterns in 3 Sizes:
- **Small (500px)** - Social media posts, web icons
- **Medium (1000px)** - Website sections, email headers  
- **Large (2000px)** - Print materials, high-res backgrounds

### 6 Unique Pattern Styles:

#### 1. **Unity Kente** 🟨⬛
Traditional Ghanaian Kente-inspired geometric grid
- **Best for:** Headers, borders, formal materials
- **Cultural significance:** Represents achievement and unity
- **Usage:** 10-20% opacity for backgrounds

#### 2. **Adire Circles** 🔵⭕
Yoruba textile-inspired circular motifs
- **Best for:** Accents, decorative elements
- **Cultural significance:** Nigerian heritage and resilience
- **Usage:** Feature elements, section dividers

#### 3. **Celebration Diagonal** 🎊
Dynamic energy pattern with movement
- **Best for:** Event promotions, party materials
- **Cultural significance:** Festival energy and joy
- **Usage:** Hero sections, call-to-action backgrounds

#### 4. **Lagos Energy** ⚡
Urban pulse and Danfo-inspired vibrancy
- **Best for:** Lagos-specific content
- **Cultural significance:** City hustle and creativity
- **Usage:** Social media, youth-focused content

#### 5. **Accra Heritage** ⭐
Black Star and Pan-African symbolism
- **Best for:** Accra content, cultural pieces
- **Cultural significance:** Independence and pride
- **Usage:** Premium materials, cultural events

#### 6. **Rhythm Visualization** 🎵
Afrobeats and music-inspired bars
- **Best for:** Music events, concert promotions
- **Cultural significance:** Musical heritage
- **Usage:** Entertainment content, playlists

---

## 🎨 Implementation Tips

### Website Usage
```css
/* CSS Example */
.hero-section {
    background-image: url('pattern.png');
    background-repeat: repeat;
    background-size: 200px;
    opacity: 0.15;
}
```

### Social Media Templates
- Instagram Posts: Pattern at 20% opacity
- Stories: Vertical pattern strips
- Twitter Headers: Horizontal pattern band

### Print Materials
- Business Cards: Edge pattern accent
- Posters: Full-bleed background at 10%
- Merchandise: Pocket or sleeve details

---

## ⚠️ Cultural Respect Guidelines

### DO ✅
- Use patterns respectfully
- Credit cultural origins when appropriate
- Maintain pattern integrity
- Use subtle opacity for backgrounds
- Combine maximum 2 patterns per design

### DON'T ❌
- Distort or stretch patterns
- Use sacred patterns inappropriately
- Mix too many patterns (chaos)
- Use at 100% opacity (overwhelming)
- Appropriate without acknowledgment

---

## 🔄 Pattern Combinations

### Best Pairings:
1. **Unity Kente + Adire Circles** = Traditional elegance
2. **Lagos Energy + Celebration Diagonal** = Party vibes
3. **Accra Heritage + Unity Kente** = Cultural depth
4. **Rhythm + Lagos Energy** = Music festival
5. **Adire + Coastal** = Sophisticated calm

### Color Overlays:
- **Gold overlay:** Premium feel
- **Black overlay:** Sophistication
- **Red overlay:** Energy boost
- **Emerald overlay:** Cultural depth

---

## 💻 Digital Formats

### Available Files:
- **PNG**: Transparent background, high quality
- **SVG**: Vector format (in HTML files)
- **ZIP**: Complete package for easy download

### File Naming Convention:
`onedettydecember_[pattern-name]_[size]px.png`

---

## 📱 Responsive Usage

### Mobile (< 768px)
- Use 500px patterns
- Reduce to 5-10% opacity
- Simplify to single pattern

### Tablet (768-1024px)
- Use 1000px patterns
- 10-15% opacity
- Can combine 2 patterns

### Desktop (> 1024px)
- Use 2000px patterns
- 15-20% opacity
- Full pattern combinations

---

## 🎯 Quick Application Guide

| Content Type | Pattern | Opacity | Position |
|-------------|---------|---------|----------|
| Homepage Hero | Unity Kente | 15% | Full background |
| Event Page | Celebration | 20% | Top section |
| Blog Posts | Adire Circles | 10% | Side accent |
| CTAs | Lagos Energy | 25% | Button background |
| Forms | Accra Heritage | 5% | Subtle background |
| Footer | Rhythm | 10% | Bottom border |

---

## 📊 Performance Tips

1. **Optimize file size**: Use TinyPNG for web
2. **Lazy load**: Load patterns as needed
3. **CSS sprites**: Combine small patterns
4. **SVG alternative**: Use for scalability
5. **Cache**: Set long cache headers

---

## 🌍 Cultural Context

These patterns merge two rich textile traditions:

**Kente (Ghana)**: 
- Sacred geometry
- Royal heritage
- Each pattern tells a story

**Adire (Nigeria)**:
- Indigo resist dyeing
- Yoruba artistic expression
- Symbols of resilience

By unifying these traditions, OneDettyDecember celebrates the shared excellence of West African culture while respecting each tradition's unique significance.

---

## 📥 Download Links

All patterns are available in:
- `/patterns/` folder (individual files)
- `onedettydecember_patterns.zip` (complete package)

---

## 🤝 Attribution

When using these patterns publicly:
```
Patterns inspired by traditional Kente (Ghana) 
and Adire (Nigeria) textile arts.
Designed for OneDettyDecember - Where Lagos Meets Accra
```

---

## Need Help?

- Pattern customization requests
- Cultural consultation
- Implementation support

Contact: design@onedettydecember.com

---

*Version 1.0 | November 2025*
*© OneDettyDecember - Celebrating West African Excellence*